## [4.4.1] - 2019-12-20
### Added
- License info at the top of public headers
### Fixed
- Timeout for network requests is 5 minutes.
### Added
- Log message of actual path where debug screenshots are saved(if flag saveDebugScreenshots is set to true)
### Fixed 
- Nullability warnings
### Added
- "Accept" HTTP header with value "application/json"
### Fixed
- Work with regions those got floating x,, y, width and height values
### Added
- Support of APPLITOOLS_SERVER_URL environment
- Support of all existent environment variables with "bamboo_" prefix

## [4.4.0] - 2019-11-5
### Added
- Configuration API.
### Added
- CHANGELOG file for EyesImages SDK.
.
